KELIME YOLCULUGU - ANDROID STUDIO PROJESI

1. Bu ZIP'i bilgisayara çıkarın.
2. Android Studio > Open ile KelimeYolculugu-AndroidStudio klasörünü açın.
3. Gradle senkronizasyonunun tamamlanmasını bekleyin.
4. Build > Build APK(s) seçin.
5. APK: app/build/outputs/apk/debug/app-debug.apk

Oyun dosyası app/src/main/assets/index.html içindedir.
